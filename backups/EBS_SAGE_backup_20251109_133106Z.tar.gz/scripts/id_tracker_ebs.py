#!/usr/bin/env python3
"""
ID Tracker EBS - Prevent duplicate processing for EBS system
Thread-safe JSON file tracking
"""
import json
import os
from datetime import datetime
from threading import Lock
from pathlib import Path

TRACKER_FILE = os.getenv('EBS_TRACKER_FILE', str(Path(__file__).resolve().parent / 'processed_ids_ebs.json'))
_lock = Lock()

def load_tracker():
    """Load processed IDs"""
    if not os.path.exists(TRACKER_FILE):
        return {"newsbrief_digests": [], "tweets": [], "last_updated": datetime.now().isoformat()}
    
    with _lock:
        with open(TRACKER_FILE, 'r') as f:
            return json.load(f)

def save_tracker(tracker):
    """Save processed IDs"""
    tracker['last_updated'] = datetime.now().isoformat()
    with _lock:
        with open(TRACKER_FILE, 'w') as f:
            json.dump(tracker, f, indent=2)

def is_digest_processed(digest_id):
    """Check if NewsBreif digest was already split"""
    tracker = load_tracker()
    return digest_id in tracker.get('newsbrief_digests', [])

def mark_digest_processed(digest_id):
    """Mark NewsBreif digest as processed"""
    tracker = load_tracker()
    if digest_id not in tracker.get('newsbrief_digests', []):
        tracker['newsbrief_digests'].append(digest_id)
        save_tracker(tracker)
