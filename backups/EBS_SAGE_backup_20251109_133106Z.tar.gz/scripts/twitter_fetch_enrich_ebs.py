#!/usr/bin/env python3
"""
Unified Twitter Fetcher + Enricher for EBS LanceDB
Fetches 20 tweets, enriches them (keywords + AI score), stores in one run
"""
import os
import requests
import lancedb
import pandas as pd
import json
import time
from datetime import datetime
from pathlib import Path
import pytz
import anthropic

print("🐦 Twitter Fetcher + Enricher - EBS LanceDB (Unified Batch)")
print("="*80)

# Configuration
BASE_DIR = Path(__file__).resolve().parent.parent

TWITTERAPI_KEY = os.environ.get('TWITTERAPI_KEY')
if not TWITTERAPI_KEY:
    raise RuntimeError('Set TWITTERAPI_KEY environment variable before running the Twitter fetcher')

LIST_ID = os.environ.get('TWITTER_LIST_ID', '1955968749036572718')
EBS_DB = os.environ.get('EBS_LANCEDB_PATH', '/mnt/lancedb')
BATCH_SIZE = int(os.environ.get('TWITTER_BATCH_SIZE', 20))

# Tracker file
TRACKER_FILE = os.environ.get('EBS_TRACKER_FILE', str(BASE_DIR / 'processed_ids_ebs.json'))

ANTHROPIC_KEY = os.environ.get('ANTHROPIC_API_KEY')
if not ANTHROPIC_KEY:
    raise RuntimeError('Set ANTHROPIC_API_KEY environment variable before running the Twitter fetcher')

anthropic_client = anthropic.Anthropic(api_key=ANTHROPIC_KEY)

def load_tracker():
    """Load processed IDs"""
    if os.path.exists(TRACKER_FILE):
        with open(TRACKER_FILE, 'r') as f:
            return json.load(f)
    return {"tweets": []}

def save_tracker(tracker):
    """Save processed IDs"""
    with open(TRACKER_FILE, 'w') as f:
        json.dump(tracker, f, indent=2)

def enrich_tweet(tweet_text: str, username: str) -> dict:
    """Enrich tweet with Claude API - keywords + AI score"""
    prompt = f"""Analyze this financial tweet and extract JSON data.

Tweet from @{username}: {tweet_text}

Return ONLY JSON (no markdown):
{{"keywords": ["term1", "term2", "term3"], "main_actors": {{"people": [], "organizations": [], "tickers": [], "countries": []}}, "ai_enrichment": {{"relevance_score": 5, "category": "other", "sentiment": "neutral", "market_impact": "low", "reasoning": "brief reason"}}}}

IMPORTANT:
- relevance_score: 1-10 scale (10 = highly relevant to financial markets)
- keywords: 4-6 relevant financial/market keywords
- Use the FULL range (1-10), differentiate scores"""

    try:
        response = anthropic_client.messages.create(
            model="claude-3-5-haiku-20241022",
            max_tokens=512,
            temperature=0.3,
            messages=[{"role": "user", "content": prompt}]
        )
        result = response.content[0].text.strip()
        if result.startswith("```"):
            result = result.split("```")[1]
            if result.startswith("json"):
                result = result[4:]
        enrichment = json.loads(result.strip())
        enrichment['ai_enrichment']['enriched_at'] = datetime.now(pytz.UTC).isoformat()
        enrichment['ai_enrichment']['model'] = 'claude-3-5-haiku-20241022'
        return enrichment
    except Exception as e:
        print(f"     ⚠️ Enrichment error: {str(e)[:100]}")
        return {
            "keywords": [],
            "main_actors": {"people": [], "organizations": [], "tickers": [], "countries": []},
            "ai_enrichment": {
                "relevance_score": 0,
                "category": "other",
                "sentiment": "neutral",
                "market_impact": "low",
                "reasoning": f"Error: {str(e)[:50]}",
                "enriched_at": datetime.now(pytz.UTC).isoformat(),
                "model": "claude-3-5-haiku-20241022"
            }
        }

# Load tracker
tracker = load_tracker()
processed_ids = set(tracker.get("tweets", []))

print(f"Time: {datetime.now()}")
print(f"Batch size: {BATCH_SIZE}")
print(f"Database: {EBS_DB}")
print(f"📊 Already processed: {len(processed_ids)} tweets\n")

# Connect to EBS database
print("📂 Connecting to EBS database...")
db = lancedb.connect(EBS_DB)
table = db.open_table('unified_feed')

# Get existing tweets
existing_df = table.to_pandas()
existing_tweets = existing_df[existing_df['source_type'] == 'tweet'] if not existing_df.empty else pd.DataFrame()
existing_ids = set(existing_tweets['id'].tolist()) if not existing_tweets.empty else set()

print(f"📊 Existing tweets in EBS: {len(existing_ids)}\n")

# Fetch tweets from TwitterAPI.io
print(f"📥 Fetching {BATCH_SIZE} fresh tweets from TwitterAPI.io...\n")
url = "https://api.twitterapi.io/twitter/list/tweets"
headers = {"x-api-key": TWITTERAPI_KEY}
params = {"listId": LIST_ID, "count": BATCH_SIZE}

response = requests.get(url, headers=headers, params=params, timeout=30)

if response.status_code != 200:
    print(f"❌ API Error: {response.status_code}")
    print(response.text)
    exit(1)

data = response.json()
tweets = data.get('tweets', [])

print(f"✅ Retrieved {len(tweets)} tweets\n")

# Process and enrich tweets
new_tweets = []
media_count = 0
skipped = 0
enriched_count = 0

print(f"🔄 Processing and enriching {len(tweets)} tweets...\n")

for i, tweet in enumerate(tweets, 1):
    tweet_id = f"tweet_{tweet.get('id')}"
    
    # Skip if already processed or exists
    if tweet_id in processed_ids or tweet_id in existing_ids:
        skipped += 1
        continue
    
    # Extract author
    author = tweet.get('author', {})
    username = author.get('userName', 'unknown')
    display_name = author.get('name', username)
    
    # Extract text
    tweet_text = tweet.get('text', '')
    
    # Extract URLs
    urls = tweet.get('urls', [])
    first_url = urls[0].get('expanded_url', '') if urls else ''
    
    # Parse timestamp
    created_str = tweet.get('created_at', '')
    if created_str:
        try:
            created_at = datetime.fromisoformat(created_str.replace('Z', '+00:00'))
        except:
            created_at = datetime.now(pytz.UTC)
    else:
        created_at = datetime.now(pytz.UTC)
    
    created_at_iso = created_at.isoformat()
    
    # Extract media
    media_list = []
    has_media = False
    media_items = tweet.get('media', [])
    
    for media_item in media_items:
        media_type = media_item.get('type', '')
        if media_type in ['photo', 'video']:
            if media_type == 'photo':
                media_list.append({
                    'type': 'photo',
                    'url': media_item.get('media_url_https', '')
                })
                has_media = True
            elif media_type == 'video':
                variants = media_item.get('video_info', {}).get('variants', [])
                best_video = None
                best_bitrate = 0
                for variant in variants:
                    if variant.get('content_type') == 'video/mp4':
                        bitrate = variant.get('bitrate', 0)
                        if bitrate > best_bitrate:
                            best_bitrate = bitrate
                            best_video = variant
                
                thumbnail = media_item.get('media_url_https', '')
                
                if best_video:
                    media_list.append({
                        'type': media_type,
                        'url': best_video.get('url'),
                        'thumbnail': thumbnail
                    })
                    has_media = True
    
    if has_media:
        media_count += 1
    
    # Enrich tweet with AI
    print(f"  [{i}/{len(tweets)}] Enriching @{username}...")
    enrichment = enrich_tweet(tweet_text, username)
    
    # Extract enrichment data
    keywords = enrichment.get('keywords', [])
    ai_data = enrichment.get('ai_enrichment', {})
    ai_score = float(ai_data.get('relevance_score', 0))
    
    # Format keywords for storage
    keywords_str = ' • '.join(keywords[:6]) if keywords else ''
    
    # Build enriched content with keywords
    enriched_content = tweet_text
    if keywords_str:
        enriched_content = f"{tweet_text}\n\n🔑 {keywords_str}"
    
    # Build custom_fields
    custom_fields = {
        'display_name': display_name,
        'likes': tweet.get('likeCount', 0),
        'retweets': tweet.get('retweetCount', 0),
        'replies': tweet.get('replyCount', 0),
        'views': tweet.get('viewCount', 0),
        'has_media': has_media,
        'media': media_list
    }
    
    new_tweets.append({
        'id': tweet_id,
        'source_type': 'tweet',
        'created_at': created_at_iso,
        'author': '',
        'author_email': '',
        'sender_tag': f"@{username}",
        'title': str(tweet_text[:200] + ('...' if len(tweet_text) > 200 else '')),
        'content_html': '',
        'content_text': str(tweet_text),
        'enriched_content': enriched_content,
        'actors': json.dumps(enrichment.get('main_actors', {})),
        'themes': keywords_str,
        'link': str(first_url),
        'ai_score': ai_score,
        'ai_relevance_score': ai_score,
        'is_junk': False,
        'is_attention': False,
        'custom_fields': json.dumps(custom_fields)
    })
    
    processed_ids.add(tweet_id)
    enriched_count += 1
    
    # Small delay between enrichments to avoid rate limits
    if i < len(tweets):
        time.sleep(0.5)

print(f"\n📊 Results:")
print(f"   ✅ New tweets: {len(new_tweets)}")
print(f"   ✅ Enriched: {enriched_count}")
print(f"   ⏭️ Skipped (already processed): {skipped}")
print(f"   📷 With media: {media_count}\n")

# Add to database
if new_tweets:
    print(f"💾 Adding {len(new_tweets)} enriched tweets to EBS database...")
    
    new_df = pd.DataFrame(new_tweets)
    table.add(new_df)
    print(f"   ✅ Added {len(new_tweets)} tweets")
    
    # Save tracker
    tracker["tweets"] = list(processed_ids)
    save_tracker(tracker)
else:
    print("ℹ️ No new tweets to add\n")

# Final count
final_df = table.to_pandas()
final_tweets = final_df[final_df['source_type'] == 'tweet'] if not final_df.empty else pd.DataFrame()

print("="*80)
print(f"✅ Complete! EBS database now has {len(final_tweets)} tweets")
print(f"   📊 Average AI score: {final_tweets['ai_score'].mean():.1f}/10" if not final_tweets.empty else "")
print("="*80)
