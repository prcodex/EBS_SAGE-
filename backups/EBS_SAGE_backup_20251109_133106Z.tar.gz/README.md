# EBS SAGE (Port 8545) Backup

This repository captures the clean insert-only SAGE stack running on AWS EBS (port 8545). It includes:

- `app/sage_ebs_clean.py`: Flask interface pointing at the EBS LanceDB instance.
- `scripts/newsbrief_batch_ebs.py`: Gmail → NewsBrief batch processor (INSERT-only).
- `scripts/twitter_fetch_enrich_ebs.py`: TwitterAPI.io fetcher + Claude enrichment pipeline.
- `scripts/tweet_junk_classifier_ebs.py`: Auto-junks low-score tweets without touching user junk.
- `scripts/id_tracker_ebs.py`: Shared processed-ID tracker for both pipelines.
- `handlers/`: Claude handlers reused by the batch scripts.
- `templates/sage_4.0_interface.html`: Shared UI template (same as production white interface).

## Environment variables

Set these before running any scripts:

| Variable | Description |
| --- | --- |
| `EBS_LANCEDB_PATH` | Absolute path to LanceDB database (default `/mnt/lancedb_clean` for Flask, `/mnt/lancedb` for tweets). |
| `EBS_LANCEDB_TABLE` | Target table name (default `unified_feed`). |
| `TWITTERAPI_KEY` | TwitterAPI.io key for list fetching. |
| `TWITTER_LIST_ID` | Tweet list ID (defaults to Pedro's curated list). |
| `TWITTER_BATCH_SIZE` | Optional batch override (defaults to 20). |
| `EBS_TRACKER_FILE` | Path to processed ID JSON (defaults to `processed_ids_ebs.json` in repo root). |
| `GMAIL_USER` / `GMAIL_APP_PASSWORD` | NewsBrief Gmail credentials. |
| `ANTHROPIC_API_KEY` | Claude key reused by NewsBrief + Twitter enrichment. |
| `KEYWORD_EXCLUSIONS_PATH` | Optional JSON for keyword exclusions (defaults to `keyword_exclusions.json` beside scripts). |

## Usage

1. Install dependencies: `pip install -r requirements.txt`.
2. Export environment variables (see above).
3. Launch Flask UI: `python app/sage_ebs_clean.py` (runs on port 8545 by default).
4. Run NewsBrief batch (INSERT-only): `python scripts/newsbrief_batch_ebs.py`.
5. Run Twitter fetch/enrich: `python scripts/twitter_fetch_enrich_ebs.py`.
6. Run junk classifier: `python scripts/tweet_junk_classifier_ebs.py` (optional, after enrichment).

Both batch scripts append only, using `processed_ids_ebs.json` to avoid reprocessing and keep Claude/API costs low.

## Notes

- No hard-coded secrets: everything relies on environment variables.
- UI template is identical to production SAGE 8540 (white theme) for side-by-side comparisons.
- Replace `processed_ids_ebs.json` with a persistent path if running from cron.
- The repository is intended as a portable backup of the EBS system requested on Nov 7, 2025.


## Latest Updates (2025-11-08)

- NewsBrief batch processor now parses email RFC-2822 dates with timezone awareness before storing UTC timestamps.
- Added `scripts/twitter_fetch_to_ebs_tracker.py`, matching the 8540 media fetcher but targeting the EBS LanceDB path with a tracker to prevent duplicate inserts.
- Cron examples updated below to reflect the new Twitter fetcher and NewsBrief batch scripts.

## Cron Examples

```
# Every 15 minutes: fetch latest tweets into EBS
*/15 * * * * cd /home/ubuntu/newspaper_project && /usr/bin/env python3 twitter_fetch_to_ebs_tracker.py >> /home/ubuntu/logs/ebs_clean/twitter_fetch.log 2>&1

# Every 20 minutes: split and enrich NewsBrief digests (insert-only)
*/20 * * * * cd /home/ubuntu/newspaper_project && /usr/bin/env python3 newsbrief_batch_ebs.py >> /home/ubuntu/logs/ebs_clean/newsbrief_batch.log 2>&1
```

Remember to export the required environment variables (see table above) before installing the cron jobs.
