from flask import Flask, render_template, jsonify, request
import json
import os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('admin_complete.html')

@app.route('/api/allowed_senders')
def get_allowed_senders():
    """Get list of allowed senders (tags only)"""
    try:
        with open('allowed_senders.json', 'r') as f:
            data = json.load(f)
        
        if isinstance(data, list):
            senders = list(set([item.get('sender_tag', '') for item in data if item.get('sender_tag')]))
            senders.sort()
        else:
            senders = data.get('senders', [])
        
        return jsonify({'senders': senders})
    except Exception as e:
        print(f"Error loading allowed senders: {e}")
        return jsonify({'senders': []}), 500

@app.route('/api/allowed_senders_full')
def get_allowed_senders_full():
    """Get full allowlist data with email patterns"""
    try:
        with open('allowed_senders.json', 'r') as f:
            data = json.load(f)
        
        if isinstance(data, list):
            return jsonify({'senders': data})
        else:
            return jsonify({'senders': data.get('senders', [])})
    except Exception as e:
        print(f"Error loading full allowed senders: {e}")
        return jsonify({'senders': []}), 500

@app.route('/api/update_allowed_sender', methods=['POST'])
def update_allowed_sender():
    """Create or update an allowed sender entry"""
    try:
        payload = request.get_json() or {}
        original_tag = payload.get('original_sender_tag')
        sender_tag = (payload.get('sender_tag') or '').strip()
        email_patterns = payload.get('email_patterns') or []
        description = (payload.get('description') or '').strip()

        if not sender_tag:
            return jsonify({'success': False, 'error': 'sender_tag is required'}), 400
        if not isinstance(email_patterns, list) or not email_patterns:
            return jsonify({'success': False, 'error': 'email_patterns must be a non-empty list'}), 400

        cleaned_patterns = []
        for pattern in email_patterns:
            if isinstance(pattern, str):
                trimmed = pattern.strip()
                if trimmed:
                    cleaned_patterns.append(trimmed)

        if not cleaned_patterns:
            return jsonify({'success': False, 'error': 'No valid email patterns provided'}), 400

        with open('allowed_senders.json', 'r') as f:
            raw = json.load(f)

        if isinstance(raw, dict):
            senders = raw.get('senders', [])
        else:
            senders = raw

        updated = False
        for entry in senders:
            if entry.get('sender_tag') == original_tag:
                entry['sender_tag'] = sender_tag
                entry['email_patterns'] = cleaned_patterns
                entry['description'] = description
                updated = True
                break

        if not updated:
            senders.append({
                'sender_tag': sender_tag,
                'email_patterns': cleaned_patterns,
                'description': description
            })

        with open('allowed_senders.json', 'w') as f:
            json.dump(senders, f, indent=2)

        return jsonify({
            'success': True,
            'entry': {
                'sender_tag': sender_tag,
                'email_patterns': cleaned_patterns,
                'description': description
            }
        })

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/delete_allowed_sender', methods=['POST'])
def delete_allowed_sender():
    """Delete an allowed sender"""
    try:
        data = request.get_json() or {}
        sender_tag = data.get('sender_tag')

        if not sender_tag:
            return jsonify({'success': False, 'error': 'sender_tag is required'}), 400

        with open('allowed_senders.json', 'r') as f:
            raw = json.load(f)

        if isinstance(raw, dict):
            senders = raw.get('senders', [])
        else:
            senders = raw

        filtered = [s for s in senders if s.get('sender_tag') != sender_tag]

        with open('allowed_senders.json', 'w') as f:
            json.dump(filtered, f, indent=2)

        return jsonify({'success': True, 'removed': sender_tag})

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/detection_rules')
def get_detection_rules():
    """Get all detection rules"""
    try:
        with open('tag_detection_rules.json', 'r') as f:
            rules = json.load(f)
        return jsonify(rules)
    except Exception as e:
        print(f"Error loading detection rules: {e}")
        return jsonify({}), 500

@app.route('/api/tag_mappings_data')
def get_tag_mappings_data():
    """Get tag-to-handler mappings"""
    try:
        with open('tag_handler_mappings.json', 'r') as f:
            mappings = json.load(f)
        return jsonify(mappings)
    except Exception as e:
        print(f"Error loading tag mappings: {e}")
        return jsonify({}), 500

@app.route('/api/available_handlers')
def get_available_handlers():
    """Get list of available enrichment handlers"""
    handlers = [
        "newsbrief_with_links",
        "gold_standard_enhanced",
        "rosenberg_deep_research",
        "breakfast_headlines",
        "cochrane_detailed",
        "itau_daily",
        "tony_pasquariello",
        "wsj_opinion",
        "shadow_vlm",
        "charts_vlm",
        "elerian_rep",
        "javier_blas",
        "digest",
        "bloomberg_breaking",
        "classification"
    ]
    return jsonify({'handlers': handlers})

@app.route('/api/update_tag_mapping', methods=['POST'])
def update_tag_mapping():
    """Update a tag's handler mapping"""
    try:
        data = request.get_json()
        tag = data.get('tag')
        new_handler = data.get('handler')
        
        if not tag or not new_handler:
            return jsonify({'success': False, 'error': 'Missing tag or handler'}), 400
        
        with open('tag_handler_mappings.json', 'r') as f:
            mappings = json.load(f)
        
        old_handler = mappings.get(tag, 'UNKNOWN')
        mappings[tag] = new_handler
        
        with open('tag_handler_mappings.json', 'w') as f:
            json.dump(mappings, f, indent=2)
        
        return jsonify({
            'success': True,
            'tag': tag,
            'old_handler': old_handler,
            'new_handler': new_handler
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/test_rule', methods=['POST'])
def test_rule():
    """Test a detection rule against actual emails"""
    data = request.get_json()
    
    sender = data.get('sender', '')
    subject_contains = data.get('subject_contains', '')
    body_contains = data.get('body_contains', '')
    logic = data.get('logic', 'OR')
    
    import requests
    
    try:
        response = requests.get('http://localhost:8540/api/feed', timeout=5)
        emails = response.json()
        
        matches = []
        
        for email in emails:
            email_sender = str(email.get('sender', '') or email.get('display_name', '')).lower()
            email_subject = str(email.get('title', '')).lower()
            email_content = str(email.get('content_text', '')).lower()
            
            sender_match = sender.lower() in email_sender if sender else True
            
            if subject_contains and body_contains:
                if logic == 'OR':
                    content_match = (subject_contains.lower() in email_subject or 
                                   body_contains.lower() in email_content)
                else:
                    content_match = (subject_contains.lower() in email_subject and 
                                   body_contains.lower() in email_content)
            elif subject_contains:
                content_match = subject_contains.lower() in email_subject
            elif body_contains:
                content_match = body_contains.lower() in email_content
            else:
                content_match = True
            
            if sender_match and content_match:
                matches.append({
                    'title': email.get('title', ''),
                    'sender': email.get('display_name', email.get('sender', 'Unknown')),
                    'date': email.get('created_at', ''),
                    'current_tag': email.get('sender_tag', 'NO TAG')
                })
            
            if len(matches) >= 5:
                break
        
        return jsonify({
            'success': True,
            'matches': matches[:5],
            'total_checked': len(emails),
            'total_matches': len(matches)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/keyword_exclusions')
def get_keyword_exclusions():
    """Get keyword exclusion list"""
    try:
        with open('keyword_exclusions.json', 'r') as f:
            exclusions = json.load(f)
        return jsonify(exclusions)
    except Exception as e:
        print(f"Error loading exclusions: {e}")
        return jsonify({}), 500

@app.route('/api/keyword_exclusions', methods=['POST'])
def save_keyword_exclusions():
    """Save keyword exclusion list"""
    try:
        data = request.get_json()
        with open('keyword_exclusions.json', 'w') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return jsonify({'success': True})
    except Exception as e:
        print(f"Error saving exclusions: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/handlers')
def get_handlers():
    """Get all handler configurations"""
    try:
        with open('handlers_config.json', 'r') as f:
            return jsonify(json.load(f))
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/tag_handler_map')
def get_tag_handler_map():
    """Get tag to handler mappings"""
    try:
        with open('tag_handler_mappings.json', 'r') as f:
            mappings = json.load(f)
        
        # Group by handler
        by_handler = {}
        for tag, handler in mappings.items():
            if handler not in by_handler:
                by_handler[handler] = []
            by_handler[handler].append(tag)
        
        return jsonify(by_handler)
    except Exception as e:
        return jsonify({'error': str(e)}), 500




@app.route('/api/tag_handler_mappings', methods=['GET', 'POST'])
def manage_tag_handler_mappings():
    """Get or update tag to handler mappings"""
    mappings_file = 'tag_handler_mappings.json'
    
    # Load existing mappings
    try:
        with open(mappings_file, 'r') as f:
            mappings = json.load(f)
    except:
        mappings = {}
    
    if request.method == 'GET':
        return jsonify({'mappings': mappings})
    
    elif request.method == 'POST':
        data = request.json
        action = data.get('action')
        
        if action == 'add':
            tag = data.get('tag')
            handler = data.get('handler')
            
            if not tag or not handler:
                return jsonify({'status': 'error', 'message': 'Tag and handler required'}), 400
            
            # Add the mapping
            mappings[tag] = handler
            
            # Save to file
            with open(mappings_file, 'w') as f:
                json.dump(mappings, f, indent=2)
            
            return jsonify({'status': 'success', 'message': f'Mapping added: {tag} -> {handler}'})
        
        elif action == 'delete':
            tag = data.get('tag')
            
            if not tag:
                return jsonify({'status': 'error', 'message': 'Tag required'}), 400
            
            if tag in mappings:
                del mappings[tag]
                
                # Save to file
                with open(mappings_file, 'w') as f:
                    json.dump(mappings, f, indent=2)
                
                return jsonify({'status': 'success', 'message': f'Mapping removed for tag: {tag}'})
            else:
                return jsonify({'status': 'error', 'message': f'Tag not found: {tag}'}), 404
        
        else:
            return jsonify({'status': 'error', 'message': 'Invalid action'}), 400
@app.route('/api/tagging_rules')
def get_tagging_rules():
    """Alias endpoint for compatibility"""
    return get_detection_rules()


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8543, debug=True)

@app.route('/test')
def test_page():
    return render_template('test_simple.html')


