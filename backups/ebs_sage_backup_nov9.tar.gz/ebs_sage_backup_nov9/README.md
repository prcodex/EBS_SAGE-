# EBS SAGE Backup - November 9, 2025

## System State
- **Architecture**: 2-batch ingestion + proposed 3rd analysis batch
- **Storage**: EBS at /mnt/lancedb_clean (NOT S3)
- **Ports**: 8545 (feed), 8543 (admin), 8546 (proposed analysis)

## Active Batches
1. **NewsBreif**: Every 2 hours via cron_ebs_newsbrief.sh
2. **Twitter**: Every 15 minutes via cron_wrapper.sh
3. **Analysis**: Proposed 4-hour batch (not yet implemented)

## Evolution Summary
- Started with 8540 SAGE system on S3
- Migrated to EBS for performance (10x faster)
- Split into separate batch processes
- Insert-only architecture implemented
- Junk persistence via external tracker

## Key Files
- sage_ebs_clean.py - Main feed interface (8545)
- newsbrief_batch_ebs.py - Email ingestion
- twitter_fetch_to_ebs_tracker.py - Twitter ingestion
- unified_adaptive_enrichment.py - Handler orchestrator
- handlers/ - 26 specialized enrichment handlers
- scrapex_admin.py - Admin interface (8543)

## Handler List
1. aaa_universal_handler - Fallback with source detection
2. gold_standard_enhanced - Deep thematic analysis
3. rosenberg_deep_research - 5-7 analytical bullets
4. newsbrief_with_links - Story extraction
5. itau_daily - Portuguese summaries
6. cochrane_detailed - Academic economics
7. shadow_handler - Chart analysis
8. Plus 19 more specialized handlers

## Database Schema
- Table: unified_feed
- Insert-only (no updates)
- Junk tracked externally in junked_ids.json
- ~10,000 records as of Nov 9

## Next Steps
1. Implement analysis_batch_processor.py
2. Create analysis_results table
3. Build analysis explorer interface (8546)
4. Schedule 4-hour cron for analysis
