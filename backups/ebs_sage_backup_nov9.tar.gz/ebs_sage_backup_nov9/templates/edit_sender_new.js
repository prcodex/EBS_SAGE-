        function editSender(senderTag) {
            const sender = allSenders.find(s => s.sender_tag === senderTag);
            if (!sender) { alert('Sender not found!'); return; }
            
            const modal = document.createElement('div');
            modal.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:9999;';
            modal.innerHTML = '<div style="background:white;padding:40px;border-radius:15px;max-width:600px;width:90%;"><h2 style="color:#1DA1F2;margin-bottom:20px;">✏️ Edit: ' + senderTag + '</h2><div style="margin-bottom:20px;"><label style="display:block;margin-bottom:8px;font-weight:600;">Sender Tag:</label><input type="text" id="edit-tag" value="' + sender.sender_tag + '" style="width:100%;padding:12px;border:2px solid #E1E8ED;border-radius:8px;"></div><div style="margin-bottom:20px;"><label style="display:block;margin-bottom:8px;font-weight:600;">Email Patterns (one per line):</label><textarea id="edit-patterns" rows="6" style="width:100%;padding:12px;border:2px solid #E1E8ED;border-radius:8px;font-family:monospace;">' + sender.email_patterns.join('\\n') + '</textarea><small style="color:#657786;display:block;margin-top:5px;">💡 bloomberg.com (matches anyone@bloomberg.com)<br>specific@email.com (exact match)</small></div><div style="margin-bottom:20px;"><label style="display:block;margin-bottom:8px;font-weight:600;">Description:</label><textarea id="edit-desc" rows="2" style="width:100%;padding:12px;border:2px solid #E1E8ED;border-radius:8px;">' + (sender.description || '') + '</textarea></div><div style="display:flex;gap:10px;justify-content:flex-end;"><button onclick="this.closest(\\\'[style*=position]\\\').remove()" style="padding:12px 24px;border:none;background:#657786;color:white;border-radius:8px;cursor:pointer;font-weight:600;">Cancel</button><button onclick="saveSenderEdit(\\\'' + senderTag + '\\\')" style="padding:12px 24px;border:none;background:#1DA1F2;color:white;border-radius:8px;cursor:pointer;font-weight:600;">💾 Save</button></div></div>';
            document.body.appendChild(modal);
        }
        
        function saveSenderEdit(originalTag) {
            const newTag = document.getElementById('edit-tag').value.trim();
            const patterns = document.getElementById('edit-patterns').value.split('\\n').map(p => p.trim()).filter(p => p);
            const desc = document.getElementById('edit-desc').value.trim();
            if (!newTag || patterns.length === 0) { alert('⚠️ Fill all fields!'); return; }
            alert('✅ Saved!\\n\\nTag: ' + newTag + '\\nPatterns: ' + patterns.length + '\\n\\n(Actual save to file coming soon)');
            document.querySelector('[style*="position:fixed"]').remove();
            loadAllowedSenders();
        }
